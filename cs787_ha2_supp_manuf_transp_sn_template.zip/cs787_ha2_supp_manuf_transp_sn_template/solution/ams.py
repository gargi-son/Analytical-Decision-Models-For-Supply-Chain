import copy
import json
import importlib.util
import sys
# sys.path.append("../aaa_dgalPy")
sys.path.append("./lib")
# sys.path.append("/Users/alexbrodsky/Documents/OneDrive - George Mason University - O365 Production/aaa_python_code/aaa_dgalPy")
import dgalPy as dgal

# the following is a useful Boolean function returning True if all qty's in newFlow are non-negative
# and greater than or equal to the lower bounds (lb) in flow (inFlow or outFlow)
# replace below with correct implementation if you'd like to use it in analytic models below
def flowBoundConstraint(flow,newFlow):
    return True

#--------------------------------------------------------------------
#assumptions on input data
#1. root service inFlows and outFlows are disjoint
#2. every inFlow of every subService must have a corresponding root inFlow
#   and/or a corresponding subService outFlow (i.e., an inFlow of a subService can't
#   come from nowhere)
#3. every outFlow of every subService must have a corresponding root outFlow
#   and/or a corresponding subService inFlows (i.e., an outFlow of a subService can't
#  go nowhere)
#4. every root outFlow must have at least one corresponding subService outFlow
#5. every root inFlow must have at least one corresponding subService inFlow
#----------------------------------------------------------------
# you may want to use this template for combinedSupply(input), combindManuf(input)
# and combinedTransp(input) below

def computeMetrics(shared,root,services):
    type = services[root]["type"]
    inFlow = services[root]["inFlow"]
    outFlow = services[root]["outFlow"]

    if type == "supplier":
        return {root: supplierMetrics(services[root])}
    elif type == "manufacturer":
        return {root: manufMetrics(services[root])}
    elif type == "transport":
        return {root: transportMetrics(services[root],shared)}
    elif rootService == "combinedSupply":
        return {root: combinedSupply(services[root],shared)}
    elif rootService == "combinedManuf":
        return {root: combinedManuf(services[root],shared)}
    elif rootService == "combinedTransport":
        return {root: combinedTransp(services[root],shared)}
    else:
        subServices = services[root]["subServices"]
        subServiceMetrics = dgal.merge([computeMetrics(shared,s,services) for s in subServices])
# replace below with correct cost computation
        cost = 1000

# replace below with computation of new InFlow and new OutFlow of the root service
    newInFlow = "TBD"
    newOutFlow = "TBD"
    inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
    outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)

# replace below with internal flow constraints
    internalSupplySatisfiesDemand = True

    constraints = dgal.all([ internalSupplySatisfiesDemand,
                            inFlowConstraints,
                            outFlowConstraints,
                            subServiceConstraints
                      ])
    rootMetrics = {
        root : {
            "type": type,
            "cost": cost,
            "constraints": constraints,
            "inFlow": newInFlow,
            "outFlow": newOutFlow,
            "subServices": subServices
        }
    }
    return dgal.merge([ subServiceMetrics , rootMetrics ])

# end of Compute Metrics function
# ------------------------------------------------------------------------------
def supplierMetrics(supInput):
    type = supInput["type"]
    inFlow = supInput["inFlow"]
    outFlow = supInput["outFlow"]

# replace below with correct computation
    cost=0
    for m in outFlow.keys():
        val_m = outFlow[m]
        cost = cost + (outFlow[m]['qty'] * outFlow[m]['ppu'])
        #cost=cost+val_m['qty'] * val_m['ppu']

    newOutFlow_trial={}
    for m in outFlow.keys():
         #val_m = outFlow[m]
         obj={}
         obj["qty"]=outFlow[m]['qty']
         obj["item"]=outFlow[m]['item']
         newOutFlow_trial[m]=obj

    newOutFlow = newOutFlow_trial
    constraints = flowBoundConstraint(outFlow,newOutFlow)
    return {
        "type": type,
        "cost": cost,
        "constraints": constraints,
        "inFlow": dict(),
        "outFlow": newOutFlow
    }
#---------------------------------------------------------------------------------------
# simple manufacturer
# assumption: there is an input flow for every inQtyPer1out

def manufMetrics(manufInput):
    type = manufInput["type"]
    inFlow = manufInput["inFlow"]
    outFlow = manufInput["outFlow"]
    qtyInPer1out = manufInput["qtyInPer1out"]

# replace below with correct computation
    cost = 0
    for m in outFlow.keys():
        #val_m = outFlow[m]
        cost=cost+outFlow[m]['qty'] * outFlow[m]['ppu']

    newInFlow={}

    for x in qtyInPer1out.keys():
        for i in qtyInPer1out[x].keys():
            if i in newInFlow.keys():
                newInFlow[i]['qty']= newInFlow[i]['qty'] + (outFlow[x]['qty']*qtyInPer1out[x][i])
            else:
                newInFlow[i]={
                       "qty": (outFlow[x]['qty']*qtyInPer1out[x][i]),
                      "item": inFlow[i]['item']
                    }

    newOutFlow = {}
    for o in outFlow.keys():
         for i in outFlow[o].keys():
            newOutFlow[o] = {
                "qty": outFlow[o]['qty'],
                "item": outFlow[o]['item']
            }

    inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
    outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
    constraints = dgal.all([ inFlowConstraints, outFlowConstraints])

    return { "type": type,
             "cost": cost,
             "constraints": constraints,
             "inFlow": newInFlow,
             "outFlow": newOutFlow
    }
# end of manufMetrics
#--------------------------------------------------
def transportMetrics(transportInput, shared):
    type = transportInput["type"]
    inFlow = transportInput["inFlow"]
    outFlow = transportInput["outFlow"]
    pplbFromTo = transportInput["pplbFromTo"]
    orders = transportInput["orders"]

    cost = 0
# replace below with correct implementation. Note: it is based on transportation orders
    newInFlow={}
    for od in orders:
        for o in inFlow.keys():
            if od['in'] in newInFlow.keys():
                newInFlow[od['in']]['qty'] = newInFlow[od['in']]['qty'] + od['qty']
                break
            else:
                newInFlow[od['in']]={
                    'qty': od['qty'],
                    'item':inFlow[o]['item']
                    }
                break;

#code for outflow
    newOutFlow = {}
    total_qty = 0
    for od in orders:
        for o in outFlow.keys():
            if od['out'] in newOutFlow.keys():
                newOutFlow[od['out']]['qty'] = newOutFlow[od['out']]['qty'] + od['qty']
                break;
            else:
                newOutFlow[od['out']]={
                    'qty': od['qty'],
                    'item': outFlow[o]['item']
                    }
                break;

    # item_list={}
    #
    # for r in inFlow.keys():
    #     print(inFlow.keys())
    #     print(inFlow[r])
    #     if inFlow[r]["item"] in item_list:
    #         item_list["inFlow"][r]["item"].append(r)
    #     else:
    #         item_list["inFlow"][r]["item"]=[r]
    #
    #
    # # for x in services.keys():
    # #     if x != rootService:
    #     value=0
    #     for o in ["orders"]:
    #         for r in item_list.keys():
    #             if o["in"] in item_list[r]:
    #                 value=value+(o['qty']*shared['items'][r]['weight']*["pplbFromTo"][shared["busEntities"][o["sender"]]["loc"]][shared["busEntities"][o["recipient"]]["loc"]])
    #                 print(value)
    #                 print("!!!!!!", newServices[x]["cost"])
    #         cost = cost + value

# replace below with computation of all source locations
    sourceLocations = "TBD"
# replace below with computation of a structure for all source-destination pairs in orders
    destsPerSource = "TBD"

# replace below with computation of total weight for every source-destination pair according to orders
    weightCostPerSourceDest = "TBD"
# replace below with transportation cost computation, based on, for each source-destination pair,
# on total weight and price per pound (pplb)


    inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
    outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
    constraints = dgal.all([inFlowConstraints,outFlowConstraints])
    return { "type": type,
             "cost": cost,
             "constraints": constraints,
             "inFlow": newInFlow,
             "outFlow": newOutFlow
    }
# replace below with correct implementation
def combinedSupply(input):
        shared = input["shared"]
        rootService = input["rootService"]
        services = input["services"]
        inFlow = input["services"]["sup1"]["inFlow"]
        outFlow = input["services"]["sup1"]["outFlow"]

        cost = 0

        newInFlow = "TBD"
        newOutFlow = "TBD"
        newServices = {}

        inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
        outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
        constraints = dgal.all([ inFlowConstraints, outFlowConstraints])

        newServices[rootService]={
        }
        for x in services.keys():
            if x != rootService:
                newServices[x]={
                  "type":services[x]['type'],
                  "cost":0,
                  "constraints": constraints,
                  "inFlow":services[x]['inFlow'],
                  "outFlow":{}
                }
        for x in services.keys():

            if x != rootService:
                for r in services[x]["outFlow"].keys():

                    newServices[x]["outFlow"][r]={
                     "qty":services[x]["outFlow"][r]["qty"],
                     "item":services[x]["outFlow"][r]["item"]
                    }
        rootService_sum=0
        for x in services.keys():
            if x != rootService:
                for r in newServices[x]["outFlow"].keys():
                    newServices[x]["cost"]=newServices[x]["cost"]+(services[x]["outFlow"][r]['qty']*services[x]["outFlow"][r]['ppu'])
                rootService_sum=rootService_sum+newServices[x]["cost"]

        newServices[rootService]={
         "type":services[rootService]["type"],
         "cost": rootService_sum,
         "constraints": constraints,
         "inFlow":services[rootService]["inFlow"],
         "outFlow":{},
         "subServices":services[rootService]["subServices"]
        }

        for x in newServices[rootService]["subServices"]:
            for y in services[x]["outFlow"].keys():
                newServices[rootService]["outFlow"][y]={
                "qty": services[x]["outFlow"][y]['qty'],
                "item": services[x]["outFlow"][y]['item']
                }
        cost = rootService_sum
        return {
            "cost": cost,
            "constraints": constraints,
            "rootService": rootService,
            "services": newServices
        }
def combinedManuf(input):
    shared = input["shared"]
    rootService = input["rootService"]
    services = input["services"]
    inFlow = input["services"]["tier1manuf"]["inFlow"]
    outFlow = input["services"]["tier2manuf"]["outFlow"]

    cost = 0

    newInFlow = "TBD"
    newOutFlow = "TBD"
    newServices = {}

    inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
    outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
    constraints = dgal.all([ inFlowConstraints, outFlowConstraints])

    newServices[rootService]={
    }
    for x in services.keys():
        if x != rootService:
            newServices[x]={
              "type":services[x]['type'],
              "cost":0,
              "constraints": constraints,
              "inFlow":{},
              "outFlow":{}
            }
    for x in services.keys():
        if x != rootService:
            for r in services[x]["outFlow"].keys():
                newServices[x]["outFlow"][r]={
                 "qty":services[x]["outFlow"][r]["qty"],
                 "item":services[x]["outFlow"][r]["item"]
                }
    for x in services.keys():
        if x != rootService:
            for r in services[x]["inFlow"].keys():
                newServices[x]["inFlow"][r]={
                 "qty":0,
                 "item":services[x]["inFlow"][r]["item"]
                }

    for x in services.keys():
        if x != rootService:
            for y in services[x]["qtyInPer1out"].keys():
                for r in services[x]["qtyInPer1out"][y].keys():
                        newServices[x]["inFlow"][r]['qty'] = newServices[x]["inFlow"][r]['qty'] +(services[x]["qtyInPer1out"][y][r]*services[x]["outFlow"][y]["qty"])


    rootService_sum=0
    for x in services.keys():
        if x != rootService:
            for r in newServices[x]["outFlow"].keys():
                newServices[x]["cost"]=newServices[x]["cost"]+(services[x]["outFlow"][r]['qty']*services[x]["outFlow"][r]['ppu'])
            rootService_sum=rootService_sum+newServices[x]["cost"]


    newServices[rootService]={
     "type":services[rootService]["type"],
     "cost": rootService_sum,
     "constraints": constraints,
     "inFlow":{},
     "outFlow":{},
     "subServices":services[rootService]["subServices"]
    }

    for x in services[rootService]["inFlow"].keys():
        newServices[rootService]["inFlow"][x]={
        "qty":0,
        "item":services[rootService]["inFlow"][x]["item"]
        }

    for x in services[rootService]["inFlow"].keys():
        for y in services[rootService]["subServices"]:
            if x in services[y]["inFlow"].keys():
                newServices[rootService]["inFlow"][x]['qty']=newServices[y]["inFlow"][x]["qty"]

####Logic for the outflow part in
    for x in services[rootService]["outFlow"].keys():
        newServices[rootService]["outFlow"][x]={
        "qty":0,
        "item":services[rootService]["outFlow"][x]["item"]
        }

    for x in services[rootService]["outFlow"].keys():
        for y in services[rootService]["subServices"]:
            if x in services[y]["outFlow"].keys():
                newServices[rootService]["outFlow"][x]['qty']=newServices[y]["outFlow"][x]["qty"]


    cost = rootService_sum


    return {
        "cost": cost,
        "constraints": constraints,
        "rootService": rootService,
        "services": newServices
    }

#####Combined Transport######
def combinedTransp(input):
    shared = input["shared"]
    rootService = input["rootService"]
    services = input["services"]
    inFlow = input["services"]["transp1"]["inFlow"]
    outFlow = input["services"]["transp1"]["outFlow"]

    cost = 0

    newInFlow = "TBD"
    newOutFlow = "TBD"
    newServices = {}

    inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
    outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
    constraints = dgal.all([ inFlowConstraints, outFlowConstraints])

#main structure of services.

    newServices[rootService]={
    }
    for x in services.keys():
        if x != rootService:
            newServices[x]={
              "type":services[x]['type'],
              "cost":cost,
              "constraints": constraints,
              "inFlow":{},
              "outFlow":{}
            }

    #structure of outFlow
    for x in services.keys():
        if x != rootService:
            keys= services[x]["outFlow"].keys()
            for o in services[x]["orders"]:
                if o["out"] in  newServices[x]["outFlow"].keys():
                    newServices[x]["outFlow"][o["out"]]['qty']=newServices[x]["outFlow"][o["out"]]['qty']+o['qty']
                else:
                    newServices[x]["outFlow"][o["out"]]={
                     'qty':o['qty'],
                     'item':services[x]["outFlow"][o["out"]]['item']
                    }

#structure of inFlow
    for x in services.keys():
        if x != rootService:
            keys= services[x]["inFlow"].keys()
            for o in services[x]["orders"]:
                if o["in"] in  newServices[x]["inFlow"].keys():
                    newServices[x]["inFlow"][o["in"]]['qty']=newServices[x]["inFlow"][o["in"]]['qty']+o['qty']
                else:
                    newServices[x]["inFlow"][o["in"]]={
                     'qty':o['qty'],
                     'item':services[x]["inFlow"][o["in"]]['item']
                    }

    item_list={}

    for x in services.keys():
        if x != rootService:
            for r in services[x]["inFlow"].keys():
                if services[x]["inFlow"][r]["item"] in item_list:
                    item_list[services[x]["inFlow"][r]["item"]].append(r)
                else:
                    item_list[services[x]["inFlow"][r]["item"]]=[r]

    for x in services.keys():
        if x != rootService:
            value=0
            for o in services[x]["orders"]:
                for r in item_list.keys():
                    if o["in"] in item_list[r]:
                        value=value+(o['qty']*shared['items'][r]['weight']*services[x]["pplbFromTo"][shared["busEntities"][o["sender"]]["loc"]][shared["busEntities"][o["recipient"]]["loc"]])
                        # print(value)
                        # print("!!!!!!", newServices[x]["cost"])
            newServices[x]["cost"]=value
            cost = cost + newServices[x]["cost"]


    newServices[rootService]={
     "type":services[rootService]["type"],
     "cost": cost,
     "constraints": constraints,
     "inFlow":{},
     "outFlow":{},
     "subServices":services[rootService]["subServices"]
    }

    for x in services.keys():
        if x != rootService:
            for r in services[x]["outFlow"].keys():
                if r in newServices[rootService]["outFlow"].keys():
                    newServices[rootService]["outFlow"][r]["qty"]=newServices[rootService]["outFlow"][r]["qty"]+newServices[x]["outFlow"][r]["qty"]
                else:
                    newServices[rootService]["outFlow"][r] = {
                       "qty": newServices[x]["outFlow"][r]["qty"],
                       "item": newServices[x]["outFlow"][r]["item"]
                    }

    for x in services.keys():
        if x != rootService:
            for r in services[x]["inFlow"].keys():
                if r in newServices[rootService]["inFlow"].keys():
                    newServices[rootService]["inFlow"][r]["qty"]=newServices[rootService]["inFlow"][r]["qty"]+newServices[x]["inFlow"][r]["qty"]
                else:
                    newServices[rootService]["inFlow"][r] = {
                       "qty": newServices[x]["inFlow"][r]["qty"],
                       "item": newServices[x]["inFlow"][r]["item"]
                    }
    # cost = rootService_sum



    # for x in services.keys():
    #     if x != rootService:
    #         sup={}
    #
    #         for o in services[x]["orders"]:
    #             for r in item_list.keys():
    #                 if o["in"] in item_list[r]:
    #                     if o["sender"] in sup.keys():
    #                         sup[o["sender"]] = sup[o["sender"]]+ (o["qty"]*shared["items"][r]["weight"])
    #                     else:
    #                         sup[o["sender"]] = (o["qty"]*shared["items"][r]["weight"])
    #
    #         # newServices[x]["cost"]=value

    return {
        "cost": cost,
        "constraints": constraints,
        "rootService": rootService,
        "services": newServices
    }
